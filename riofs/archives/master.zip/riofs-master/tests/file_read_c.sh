for i in {1..100}
do
    echo "readin .."
    cat $1
done  
